module.exports = {
  windowWidth: 1400,
  windowHeight: 1200,
  quitLine: 20000000,
  restartLine: 200000,
  waitingTime: 40000,
};
